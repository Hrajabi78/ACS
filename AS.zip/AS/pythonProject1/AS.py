import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random
import matplotlib as mpl
cmap = mpl.colormaps.get_cmap('tab20')
import matplotlib
matplotlib.use('TkAgg')

def build_random_connected_graph(rows=20, cols=20, max_spacing=10.0):

    G = nx.Graph()
    coords = {}

    for i in range(rows):
        for j in range(cols):
            x = j * max_spacing + np.random.uniform(0, max_spacing)
            y = i * max_spacing + np.random.uniform(0, max_spacing)
            node = (x, y)
            coords[(i, j)] = node
            G.add_node(node, pos=(x, y))

    for i in range(rows):
        for j in range(cols):
            u = coords[(i, j)]
            if j+1 < cols:
                v = coords[(i, j+1)]
                dist = np.linalg.norm(np.array(u) - np.array(v))
                G.add_edge(u, v, length=dist)
            if i+1 < rows:
                v = coords[(i+1, j)]
                dist = np.linalg.norm(np.array(u) - np.array(v))
                G.add_edge(u, v, length=dist)

    return G

G = build_random_connected_graph(rows=30, cols=30, max_spacing=10.0)
pos = nx.get_node_attributes(G, 'pos')

plt.figure(figsize=(8, 8))
nx.draw(G, pos, node_size=30, node_color="lightblue")
plt.title("Random Connected Grid Graph")
plt.show()

num_ants = 1000
num_generations = 100
rho = 0.8
alpha = 0.3
beta = 0.1
pheromone = {edge: 1 for edge in G.edges()}
eta = {edge: 1 / G.edges[edge]['length'] for edge in G.edges()}

nodes_list = list(G.nodes())

def get_random_source_target():
    while True:
        source = random.choice(nodes_list)
        target = random.choice(nodes_list)
        if nx.has_path(G, source, target) and source != target:
            return source, target

def construct_path(source, target):
    path = [source]
    visited = set()
    visited.add(source)
    current = source
    while current != target:
        neighbors = [n for n in G.neighbors(current) if n not in visited]
        if not neighbors:
            return None
        probs = []
        for n in neighbors:
            edge = (current, n) if (current, n) in pheromone else (n, current)
            prob = (pheromone[edge] ** alpha) * (eta[edge] ** beta)
            probs.append(prob)
        probs_sum = sum(probs)
        probs = [p/probs_sum for p in probs]
        next_node = random.choices(neighbors, weights=probs, k=1)[0]
        path.append(next_node)
        visited.add(next_node)
        current = next_node
    return path

def path_length(path):
    length = 0
    for i in range(len(path)-1):
        edge = (path[i], path[i+1]) if (path[i], path[i+1]) in G.edges() else (path[i+1], path[i])
        length += G.edges[edge]['length']
    return length

all_paths_per_generation = {}
best_path_overall = None
best_length_overall = float('inf')
best_path_in_generation_ago ={"best_path_gen" : 0 ,"best_length_gen" : 0}

source, target = get_random_source_target()
print("مبدا:", source, "مقصد:", target)

for gen in range(num_generations):
    all_paths = []
    all_lengths = []
    for ant in range(num_ants):
        path = construct_path(source, target)
        if path is None:
            continue
        length = path_length(path)
        all_paths.append(path)
        all_lengths.append(length)
    if not all_paths:
        continue
    all_paths_per_generation[gen + 1] = all_paths
    min_idx = np.argmin(all_lengths)
    best_path_gen = all_paths[min_idx]
    best_length_gen = all_lengths[min_idx]
    print(f"نسل {gen+1}: بهترین طول = {best_length_gen:.2f}")

    for edge in pheromone:
        pheromone[edge] *= (1 - rho)

    edge_deltas = {edge: 0.0 for edge in pheromone}
    if gen == 0:
        for i in range(len(best_path_gen) - 1):
            e = (best_path_gen[i], best_path_gen[i+1]) if (best_path_gen[i], best_path_gen[i+1]) in edge_deltas else (best_path_gen[i+1], best_path_gen[i])
            edge_deltas[e] += 1/best_length_gen
        for edge in pheromone:
            pheromone[edge] += rho * edge_deltas[edge]
    else:
        edge_deltas = {edge: 0.0 for edge in pheromone}
        path = best_path_in_generation_ago["best_path_gen"]
        delta = 1/best_path_in_generation_ago["best_length_gen"]
        for i in range(len(path)-1):
            e = (path[i], path[i+1]) if (path[i], path[i+1]) in edge_deltas else (path[i+1], path[i])
            edge_deltas[e] += delta
        for edge in pheromone:
            pheromone[edge] += rho * edge_deltas[edge]
        edge_deltas = {edge: 0.0 for edge in pheromone}
        for i in range(len(best_path_gen) - 1):
            e = (best_path_gen[i], best_path_gen[i+1]) if (best_path_gen[i], best_path_gen[i+1]) in edge_deltas else (best_path_gen[i+1], best_path_gen[i])
            edge_deltas[e] += 1/best_length_gen
        for edge in pheromone:
            pheromone[edge] += rho * edge_deltas[edge]

    if best_length_gen < best_length_overall:
        best_path_overall = best_path_gen
        best_length_overall = best_length_gen
        best_path_in_generation_ago["best_path_gen"] = best_path_overall
        best_path_in_generation_ago["best_length_gen"] = best_length_overall

generation_to_plot = 10

if generation_to_plot not in all_paths_per_generation:
    print(f"نسل {generation_to_plot} موجود نیست. نسل‌های ذخیره‌شده: {sorted(all_paths_per_generation.keys())}")
else:
    paths = all_paths_per_generation[generation_to_plot]
    n_paths = len(paths)
    print(f"نسل {generation_to_plot}، تعداد مسیرهای ذخیره‌شده: {n_paths}")

    n_plot = len(paths)

    plt.figure(figsize=(10,10))
    nx.draw(G, pos, node_size=6, edge_color='lightgray', with_labels=False)

    for i, path in enumerate(paths):
        path_edges = []
        for j in range(len(path)-1):
            e = (path[j], path[j+1])
            path_edges.append(e)

        color = cmap(i % cmap.N)
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, width=2, edge_color=[color], alpha=0.7)
        nx.draw_networkx_nodes(G, pos, nodelist=path, node_size=15, node_color=[color], alpha=0.8)

        nx.draw_networkx_nodes(G, pos, nodelist=[path[0]], node_size=80, node_color="green", edgecolors="black", linewidths=1.2)  # شروع
        nx.draw_networkx_nodes(G, pos, nodelist=[path[-1]], node_size=80, node_color="red", edgecolors="black", linewidths=1.2)   # پایان

    title = f"نمایش حداکثر {n_plot} مسیر از نسل {generation_to_plot}"
    plt.title(title)
    plt.show()

if best_path_overall is None:
    print("هیچ مسیر معتبری پیدا نشد!")
else:
    path_edges = []
    for i in range(len(best_path_overall)-1):
        edge = (best_path_overall[i], best_path_overall[i+1])
        if edge not in G.edges():
            edge = (best_path_overall[i+1], best_path_overall[i])
        path_edges.append(edge)

    plt.figure(figsize=(12,12))
    nx.draw(G, pos, node_size=10, edge_color='lightgray', with_labels=False)
    nx.draw_networkx_nodes(G, pos, nodelist=best_path_overall, node_color='red', node_size=30)
    nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='red', width=2)
    plt.title("بهترین مسیر کلی")
    plt.show()

    print("\nبهترین مسیر کلی:")
    print(best_path_overall)
    print("طول بهترین مسیر:", best_length_overall)
